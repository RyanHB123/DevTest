﻿namespace DeveloperTest.Models
{
    public class LeadModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Company { get; set; }
        public string JobTitle { get; set; }
        public string Location { get; set; }


    }

    public class LeadsResponse
    {
        public List<LeadModel> Items { get; set; }
        public int Page { get; set; }
        public int Size { get; set; }
        public int Total { get; set; }
        public int TotalPages { get; set; }
        public int FirstEntry { get; set; }
        public int LastEntry { get; set; }
    }

}