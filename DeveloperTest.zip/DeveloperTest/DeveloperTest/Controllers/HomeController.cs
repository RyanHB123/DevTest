using DeveloperTest.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace DeveloperTest.Controllers
{
    public class HomeController : Controller
    {



        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            
            var leadsResponse = await GetLeadsAsync();
            return View(leadsResponse.Items);

        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<LeadsResponse> GetLeadsAsync()
        {
            string apiKey = Guid.NewGuid().ToString(); 

            using var client = new HttpClient();
            client.DefaultRequestHeaders.Add("x-api-key", apiKey); 

            var response = await client.GetAsync("https://warmur-interview-api.azurewebsites.net/api/Leads?page=1&size=1");
            response.EnsureSuccessStatusCode();

            var responseBody = await response.Content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<LeadsResponse>(responseBody);


        }
    }

}
